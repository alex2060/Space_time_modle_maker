from PIL import Image
def number_fixer(x):
	if len(str(x))==1:
		return "000"+str(x)
	if len(str(x))==2:
		return "00"+str(x)
	if len(str(x))==3:
		return "0"+str(x)
	return str(x)
def do_ithelper(file_location,pix0,pix1,pix2,offset,save_loc,numberoffframes):
	def test(pix,x,y):
		return not (pix[x,y][0]<=pix0+offset and pix[x,y][0]>=pix0-offset and pix[x,y][1]<=pix1+offset and pix[x,y][1]>=pix1-offset and pix[x,y][2]<=pix2+offset and pix[x,y][1]>=pix2-offset)
	number=2
	for x in range(numberoffframes):
		print("go")
		im = Image.open('ims/'+number_fixer(number)+'.png') # Can be many different formats.
		im = im.convert("RGBA")
		pix = im.load()
		print(im.size)  # Get the width and hight of the image for iterating over
		print(pix[1,1])  # Get the RGBA Value of the a pixel of an image
		width, height = im.size
		for y in range(height):
			for x in range(width):
				if not test(pix,x,y):
					#print("pass")
					pix[x, y] = (255, 255, 255, 0)
		im.save(save_loc+"cleen_V2_"+number_fixer(number)+".png", "PNG")
		print(save_loc+"cleen_"+number_fixer(number)+".png")
		print("saved")

		#wright_(around,"myframe"+str(number),number)
		number=number+1

	#do_it(test,file_location)

file_location="ims"
save_loc="cleen_output/"
im = Image.open(file_location+'/00'+str(20)+'.png')
pix = im.load()

do_ithelper(file_location,pix[0,0][0],pix[0,0][1],pix[0,0][2],float(input("offset")),save_loc,int(input("number off frams")))


